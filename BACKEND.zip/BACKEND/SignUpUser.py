# Backend for SignUpUser
import json
import boto3
from botocore.exceptions import ClientError

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('USER')

def lambda_handler(event, context):
    headers = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST,OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type'
    }
    try:
        body = json.loads(event['body'])
        username = body['username']
        password = body['password']
        # Check if user already exists
        response = table.get_item(Key={'username': username})
        if 'Item' in response:
            return {
                'statusCode': 400,
                'headers': headers,
                'body': json.dumps({'message': 'User already exists'})
            }
        # Save new user
        table.put_item(Item={
            'username': username,
            'password': password  # In production, hash this!
        })
        return {
            'statusCode': 200,
            'headers': headers,
            'body': json.dumps({'message': 'Signup successful'})
        }
    except KeyError:
        return {
            'statusCode': 400,
            'headers': headers,
            'body': json.dumps({'message': 'Missing username or password'})
        }
    except ClientError as e:
        return {
            'statusCode': 500,
            'headers': headers,
            'body': json.dumps({'message': 'DynamoDB error', 'error': str(e)})
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'headers': headers,
            'body': json.dumps({'message': 'Internal server error', 'error': str(e)})
        }