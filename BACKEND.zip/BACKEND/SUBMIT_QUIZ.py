import json
import boto3
from datetime import datetime

CORRECT_ANSWERS = {
    "1": "Paris",
    "2": "William Shakespeare",
    "3": "Mars"
}

dynamodb = boto3.resource('dynamodb')
results_table = dynamodb.Table('QUIZ_RESULTS')

def lambda_handler(event, context):
    try:
        body = json.loads(event['body'])
        username = body.get("username")
        user_answers = body.get("answers")

        if not username or not user_answers:
            return {
                "statusCode": 400,
                "headers": {
                    "Access-Control-Allow-Origin": "*",
                    "Access-Control-Allow-Methods": "POST,OPTIONS",
                    "Access-Control-Allow-Headers": "Content-Type"
                },
                "body": json.dumps({"message": "Missing username or answers"})
            }

        # Calculate score
        score = sum(1 for qid, answer in user_answers.items() if CORRECT_ANSWERS.get(qid) == answer)

        # Store the result in DynamoDB with timestamp
        timestamp = datetime.utcnow().isoformat()
        results_table.put_item(Item={
            "username": username,
            "timestamp": timestamp,
            "score": score,
            "answers": user_answers
        })

        return {
            "statusCode": 200,
            "headers": {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "POST,OPTIONS",
                "Access-Control-Allow-Headers": "Content-Type"
            },
            "body": json.dumps({
                "message": "Quiz submitted",
                "username": username,
                "score": score,
                "total": len(CORRECT_ANSWERS)
            })
        }
    except Exception as e:
        return {
            "statusCode": 500,
            "headers": {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "POST,OPTIONS",
                "Access-Control-Allow-Headers": "Content-Type"
            },
            "body": json.dumps({"message": "Submission failed", "error": str(e)})
        }