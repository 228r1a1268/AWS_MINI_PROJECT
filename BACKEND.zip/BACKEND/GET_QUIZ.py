import json

def lambda_handler(event, context):
    questions = [
        {
            "id": "1",
            "question": "What is the capital of France?",
            "options": ["Berlin", "Madrid", "Paris", "Rome"]
        },
        {
            "id": "2",
            "question": "Who wrote 'Hamlet'?",
            "options": ["Leo Tolstoy", "William Shakespeare", "Charles Dickens", "Mark Twain"]
        },
        {
            "id": "3",
            "question": "Which planet is known as the Red Planet?",
            "options": ["Earth", "Saturn", "Mars", "Jupiter"]
        }
    ]
    return {
        "statusCode": 200,
        "headers": {
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Methods": "GET,OPTIONS",
            "Access-Control-Allow-Headers": "Content-Type"
        },
        "body": json.dumps({
            "questions": questions
        })
    }