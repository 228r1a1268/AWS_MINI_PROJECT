import json
import boto3
from botocore.exceptions import ClientError

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('USER')

def lambda_handler(event, context):
    headers = {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "POST,OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type"
    }
    try:
        body = json.loads(event['body'])
        username = body['username']
        password = body['password']
        response = table.get_item(Key={'username': username})
        if 'Item' not in response:
            return {
                'statusCode': 401,
                'headers': headers,
                'body': json.dumps({'message': 'User not found'})
            }
        stored_password = response['Item'].get('password')
        if stored_password != password:
            return {
                'statusCode': 403,
                'headers': headers,
                'body': json.dumps({'message': 'Incorrect password'})
            }
        return {
            'statusCode': 200,
            'headers': headers,
            'body': json.dumps({'message': 'Login successful'})
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'headers': headers,
            'body': json.dumps({'message': 'Login failed', 'error': str(e)})
        }